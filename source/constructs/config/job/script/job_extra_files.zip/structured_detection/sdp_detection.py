import re
import pyspark.sql.functions as sf
import sdpsner
from pyspark.sql.types import ArrayType, StringType, FloatType, DoubleType, StructType, StructField

class SDPColumnDetector:
    """
    ColumnDetector is used to detect entities in a column.
    """
    def __init__(self, sdp_identifiers, job_include_keywords, job_exclude_keywords):
        self.sdp_identifiers = sdp_identifiers
        self.job_include_keywords = job_include_keywords
        self.job_exclude_keywords = job_exclude_keywords
    
    def search_context(self, rule, col_val, column_name, identifier_include_keywords, identifier_exclude_keywords):
        """
        This function serves as a function to search the context of a match.

        Args:
            rule: The regex rule to be used for searching context.
            col_val: The value in a cell to be detected.
            column_name: The name of a column
            identifier_include_keywords: The include keywords of an identifier.
            identifier_exclude_keywords: The exclude keywords of an identifier.
        """

        if identifier_include_keywords:
            valid_column_header = False
            for include_keyword in identifier_include_keywords:
                if include_keyword in column_name:
                    valid_column_header = True
                    break
        elif identifier_exclude_keywords:
            valid_column_header = True
            for exclude_keyword in identifier_exclude_keywords:
                if exclude_keyword in column_name:
                    valid_column_header = False
                    break
        else:
            valid_column_header = True
        
        score = 0
        if valid_column_header:
            if rule:
                if re.search(rule, str(col_val)):
                    score = 1
            else:
                score = 1
        return score

    def job_keyword_search(self, column_name):
        """
        job_keyword_search serves as a function to search the context of a match.
        
        Args:
            col_val: The value in a cell to be detected.

        Returns:
            result: The matches that meet the include and exclude keywords requirements.
            
        """

        search_result = None

        for keyword in self.job_include_keywords:
            if keyword in column_name:
                return ['IncludeJobKeyword', keyword]
        
        for keyword in self.job_exclude_keywords:
            if keyword in column_name:
                return ['ExcludeJobKeyword', keyword]
        return search_result
    
    def detect_column(self, col_val, column_name):
        """
        detect_column serves as a function to construct a udf 
        to detect entities inside a dataframe. 

        sdpsner predict() sample output: 
        sdpsner.predict('Mike James') = {'Mike James': [{'Identifier': 'ENGLISH-NAME', 'Score': 0.99523854}]}

        Args:
            col_val: The value in a cell to be detected
            column_name: The name of a column
        
        Returns:
            result = [{'identifier': 'CHINESE-NAME', 'score': 0.5},
                {'identifier': 'ENGLISH-NAME', 'score': 0.4}]
        """

        result = []
        job_keyword_search_result = self.job_keyword_search(str(column_name))
        if job_keyword_search_result:
            if job_keyword_search_result[0] == 'IncludeJobKeyword':
                result.append({'identifier': job_keyword_search_result[0], 'score': 1.0})
            else:
                pass
        else:
            ml_result = sdpsner.predict(str(col_val)).get(str(col_val), [])
            ml_label_mapping = {'CHINESE-NAME': 'CHINA_CHINESE_NAME',
                                'ENGLISH-NAME': 'CHINA_ENGLISH_NAME',
                                'ADDRESS': 'CHINA_ADDRESS'}

            # iterate through all identifiers(including Regex and ML) to detect entities in col_val
            for identifier in self.sdp_identifiers:
                # Get identifier and skip Glue identifier when identifier type is 2

                identifier_include_keywords = identifier.get('header_keywords', [])
                identifier_include_keywords = list(filter(None, identifier_include_keywords)) if identifier_include_keywords else []
                identifier_exclude_keywords = identifier.get('exclude_keywords', [])
                identifier_exclude_keywords = list(filter(None, identifier_exclude_keywords)) if identifier_exclude_keywords else []
                
                score = 0

                # Only perform regex matching when this column has valid column header.
                if identifier['classification'] == 1:
                    rule = identifier.get('rule', '')
                    score = self.search_context(rule, col_val, column_name, identifier_include_keywords, identifier_exclude_keywords)
                # ML matching when identifier classification is 0
                elif identifier['classification'] == 0:
                    for r in ml_result:
                        if r['Identifier'] in ml_label_mapping.keys():
                            if ml_label_mapping[r['Identifier']] == identifier['name']:
                                score = r['Score']
                result.append({'identifier': identifier['name'], 'score': float(score)})

        return result
    
    def create_detect_column_udf(self):
        # Create a udf to detect entities in a column
        detect_column_udf = sf.udf(self.detect_column, ArrayType(StructType([StructField('identifier', StringType()), StructField('score', FloatType())])))
        return detect_column_udf

def sdp_entity_detection(df, sdp_structured_identifiers, threshold, job_include_keywords, job_exclude_keywords):
    """
    sdps_entity_detection function aims to perform entity detection in SDPS.
    
    Args:
        df: the df to be detected.
        threshold: the threshold to filter out the results with score less than thresholdFraction.
        detect_column_udf: the udf to be used for entity detection.
        
    Returns:
        result_df: the df with column level SDPS detection results."""

    if len(sdp_structured_identifiers) == 0:
        return None
    
    rows = df.count()

    column_detector = SDPColumnDetector(sdp_structured_identifiers, job_include_keywords, job_exclude_keywords)
    detect_column_udf = column_detector.create_detect_column_udf()

    # Perform entity detection in SDPS
    identity_columns = {}
    for column in df.columns:
        identity_columns[column] = column+'_identity_types'
        df = df.withColumn(column+'_identity_types', detect_column_udf(column, sf.lit(column)))
    
    # Summarize the column level detection results
    expr_str = ', '.join([f"'{k}', `{v}`"for k, v in identity_columns.items()])
    expr_str = f"stack({len(identity_columns)}, {expr_str}) as (column_name,identity_types)"
    result_df = df.select(sf.expr(expr_str))\
        .select('column_name', sf.explode('identity_types'))\
        .select('col.*', '*').groupBy('column_name', 'identifier').agg(sf.sum('score').alias('score'))\
        .withColumn('score', sf.round(sf.col('score')/rows, 3))\
        .where(f'score > {threshold}')\
        .withColumn('identifier', sf.struct('identifier', 'score'))\
        .groupBy('column_name').agg(sf.collect_list('identifier').alias('identifiers'))
    
    return result_df