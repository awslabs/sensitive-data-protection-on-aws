import pyspark.sql.functions as sf

def preprocess_df(df, table_depth):
    """
    preprocess_df function aims to preprocess the df before performing entity detection.
    Select first 128 characters of each string column.
    """
    # Sample the df to size of depth
    if table_depth.isdigit():
        depth = int(table_depth)
        rows = df.count()
        sample_rate = 1.0 if rows <= depth else depth/rows

    df = df.sample(sample_rate)
    
    # Select first 128 characters of each string column
    df = df.select([sf.col(c).cast("string") for c in df.columns])
    df = df.select([sf.substring(c, 1, 128).alias(c) if t == "string" else c for c, t in df.dtypes])

    return df

def postprocess_df(result_df, sample_df, table_size):
    # Combine the results with masked sample data
    expr_str = ', '.join([f"'{c}', cast(`{c}` as string)"for c in sample_df.columns])
    expr_str = f"stack({len(sample_df.columns)}, {expr_str}) as (column_name,sample_data)"
    sample_df = sample_df.select(sf.expr(expr_str)).groupBy('column_name').agg(sf.collect_list('sample_data').alias('sample_data'))

    data_frame = result_df

    data_frame = data_frame.join(sample_df, data_frame.column_name == sample_df.column_name, 'right')\
        .select(data_frame['identifiers'], sample_df['*'])

    data_frame = data_frame.withColumn('table_size', sf.lit(table_size))

    return data_frame
    