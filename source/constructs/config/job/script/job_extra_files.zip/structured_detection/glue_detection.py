from pyspark.sql import DataFrame
import pyspark.sql.functions as sf
from awsglueml.transforms import EntityDetector
from awsglue.dynamicframe import DynamicFrame

def post_process_glue_result(glue_result_df):
    """
    post_process_glue_result function aims to filter false positive results in Glue.
    More rules will be added in this function in the future.
    """
    processed_glue_result_df = glue_result_df.filter((sf.col('entityType') != 'PERSON_NAME') | (sf.col('column_name').rlike("name|姓名|^col")))
    return processed_glue_result_df

def classifyColumnsAfterRowLevel(nonEmptySampledDf: DataFrame, thresholdFraction: float):
    """
    classifyColumnsAfterRowLevel function aims to summarize column level detection results
    after performing row level detection in Glue.
    
    Args:
        nonEmptySampledDf: the df after performing row level detection in Glue.
        thresholdFraction: the threshold to filter out the results with score less than thresholdFraction.
    
    Returns:
        glue_entities_df: the df with column level detection results.
    """

    rows = nonEmptySampledDf.count()

    glue_entities_df = nonEmptySampledDf.select(sf.explode(sf.col("DetectedEntities")).alias("column_name", "entities"))\
        .selectExpr("column_name", "explode(entities) as entity")\
        .selectExpr("column_name", "entity.entityType")
    glue_entities_df = post_process_glue_result(glue_entities_df)
    glue_entities_df = glue_entities_df.withColumn("score", sf.lit(1.0)/rows)\
        .groupBy('column_name', 'entityType').agg(sf.sum('score').alias('score'))\
        .where(f'score > {thresholdFraction}')\
        .withColumn('score', sf.round(sf.col('score'), 3))\
        .withColumnRenamed("entityType", "identifier")\
        .withColumn('identifiers', sf.struct('identifier', 'score'))\
        .groupBy('column_name').agg(sf.collect_list('identifiers').alias('identifiers'))\

    return glue_entities_df

def glue_entity_detection(df, glueContext, glue_identifiers, threshold):
    """
    glue_entity_detection function aims to perform entity detection in Glue.
    
    Args:
        df: the df to be detected.
        glueContext: the glueContext to perform entity detection.
        glue_identifiers: the identifiers to be used for entity detection in Glue.
        threshold: the threshold to filter out the results with score less than thresholdFraction.
    
    Returns:
        glue_detector_result: the df with column level detection results.
        """

    if len(glue_identifiers) == 0:
        return None

    glue_identifiers_list = []
    for identifier in glue_identifiers:
        glue_identifiers_list.append(identifier['name'])
    # Perform entity detection in Glue
    dynamic_df = DynamicFrame.fromDF(df, glueContext, "dynamic_df")

    entity_detector = EntityDetector()
    DetectSensitiveData_node1 = entity_detector.detect(
        dynamic_df,
        glue_identifiers_list,
        "DetectedEntities",
    )

    glue_detector_result = classifyColumnsAfterRowLevel(DetectSensitiveData_node1.toDF(), threshold)

    return glue_detector_result