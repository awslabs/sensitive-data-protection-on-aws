
import pyspark.sql.functions as sf
from pyspark.sql.types import ArrayType, StringType, DoubleType, StructType, StructField, IntegerType

from .process_dataframe import preprocess_df, postprocess_df
from .glue_detection import glue_entity_detection
from .sdp_detection import sdp_entity_detection

def detect_df(df, glueContext, broadcast_template, args):
    """
    detect_table is the main function to perform PII detection in a crawler table.

    Args:
        df: the df to be detected.
        glueContext: the glueContext to perform entity detection.
        broadcast_template: the broadcast template to be used for entity detection.
        args: the args dict containing all the parameters for this SDPS Job.
    
    Returns:
        result_df: the df with column level detection results.
    """

    spark = glueContext.spark_session
    threshold = float(args['DetectionThreshold'])
    glue_identifiers = broadcast_template.value.get('glue_identifiers')
    sdp_identifiers = broadcast_template.value.get('sdp_identifiers')

    raw_job_include_keywords = args['IncludeKeywords'].split(',') if args['IncludeKeywords'] else []
    job_include_keywords = list(filter(None, raw_job_include_keywords))
    raw_job_exclude_keywords = args['ExcludeKeywords'].split(',') if args['ExcludeKeywords'] else []
    job_exclude_keywords = list(filter(None, raw_job_exclude_keywords))
    
    table_size = df.count() if df else 0
    table_column_size = len(df.columns) if df else 0

    empty_df_schema = StructType([
        StructField("identifiers", ArrayType(StructType(
                        [StructField("identifier",StringType(),True),
                            StructField("score",DoubleType(),True)]
                            ),True), True),
        StructField("column_name", StringType(), True),
        StructField("sample_data", ArrayType(StringType()), True),
        StructField("table_size", IntegerType(), True)
    ])

    # If no identifier is seleted, return an empty df with default schema
    if len(glue_identifiers) == 0 and len(sdp_identifiers) == 0:
        data_frame = spark.createDataFrame([(None, "", ["No identifier is selected"], 0)], empty_df_schema)
    # If table size is 0, return an empty df with default schema
    elif table_size == 0:
        data_frame = spark.createDataFrame([(None, "", ["Table size is 0"], 0)], empty_df_schema)
    elif table_column_size == 0:
        data_frame = spark.createDataFrame([(None, "", ["Table column size is 0"], 0)], empty_df_schema)
    else:
        
        df = preprocess_df(df, args['Depth'])
        sample_df = df.limit(10)

        # Perform entity detection in Glue and SDPS
        glue_result_df = glue_entity_detection(df, glueContext, glue_identifiers, threshold)
        sdp_result_df = sdp_entity_detection(df, sdp_identifiers, threshold, job_include_keywords, job_exclude_keywords)

        # Combine the results from Glue and SDPS
        if glue_result_df == None:
            result_df = sdp_result_df
        elif sdp_result_df == None:
            result_df = glue_result_df
        else:
            union_result_df = glue_result_df.union(sdp_result_df)
            result_df = union_result_df.groupBy('column_name').agg(sf.collect_list('identifiers').alias('identifiers'))
            result_df = result_df.select('column_name', sf.flatten('identifiers').alias('identifiers'))
        
        data_frame = postprocess_df(result_df, sample_df, table_size)
    
    return data_frame