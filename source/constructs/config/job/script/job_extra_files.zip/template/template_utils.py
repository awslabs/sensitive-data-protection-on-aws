import json
import tempfile

def get_template(s3, bucket_name, template_id, template_snapshot_no):
    """
    get_template is used to download regex template file from bucket name and 
    use json to load the contents.

    Args:
        s3: The boto3 client used to download the template
        bucket_name: The bucket name to download template file from.
        template_id: The template id to download template file from.
        template_snapshot_no: The template snapshot number to download template file from.
    
    Returns:
        the regex templates as a python dict.
    """

    object_name = f"template/template-{template_id}-{template_snapshot_no}.json"
    with tempfile.TemporaryFile() as data:
        try:
            s3.download_fileobj(bucket_name, object_name, data)
            data.seek(0)
            raw_template = json.loads(data.read().decode('utf-8'))
            return preprocess_template(raw_template)
        except Exception as e:
            if template_snapshot_no == 'init':
                print(f'It seems you did not choose any identifier in the template. Empty template will be used.')
            else:
                print(f'Error occured downloading template file from {bucket_name}/{object_name}. Might be caused by recent update to 1.0.1.')
                print(e)
            raw_template = {"template_id":1,"template_name":"empty-template","identifiers":[]}
            return preprocess_template(raw_template)
        
def preprocess_template(raw_template):
    """
    preprocess_template function aims to preprocess the template before performing entity detection.
    """
    glue_identifiers, sdp_identifiers, sdp_image_identifiers = [], [], []

    # Get the Glue identifiers from the broadcast template
    identifiers = raw_template.get('identifiers')

    for identifier in identifiers:
        identifier_type = identifier.get('type', -1)
        if identifier_type == 0 or identifier_type == 1:
            sdp_identifiers.append(identifier)
        elif identifier_type == 2:
            glue_identifiers.append(identifier)
        elif identifier_type == 3:
            sdp_image_identifiers.append(identifier)
    
    identifiers_dict = {
        'glue_identifiers': glue_identifiers,
        'sdp_identifiers': sdp_identifiers,
        'sdp_image_identifiers': sdp_image_identifiers
    }

    return identifiers_dict