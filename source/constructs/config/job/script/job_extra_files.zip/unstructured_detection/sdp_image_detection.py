import re
import pyspark.sql.functions as sf
from pyspark.sql.types import ArrayType, StringType, FloatType, StructType, StructField

class SDPImageColumnDetector:
    """
    ColumnDetector is used to detect entities in a column.
    """
    def __init__(self, sdp_image_identifiers):
        self.sdp_image_identifiers = sdp_image_identifiers
    
    def detect_column(self, col_val, column_name):
        """
        detect_column serves as a function to construct a udf 
        to detect entities inside a dataframe. 

        sdpsner predict() sample output: 
        sdpsner.predict('Mike James') = {'Mike James': [{'Identifier': 'ENGLISH-NAME', 'Score': 0.99523854}]}

        Args:
            col_val: The value in a cell to be detected
            column_name: The name of a column
        
        Returns:
            result = [{'identifier': 'CHINESE-NAME', 'score': 0.5},
                {'identifier': 'ENGLISH-NAME', 'score': 0.4}]
        """

        result = []

        # iterate through all identifiers(including Regex and ML) to detect entities in col_val
        for identifier in self.sdp_image_identifiers:
            # Get identifier and skip Glue identifier when identifier type is 2

            score = 0
            if identifier['rule']:
                if re.search(identifier['rule'], str(col_val)):
                    score = 1

            result.append({'identifier': identifier['name'], 'score': float(score)})

        return result
    
    def create_detect_image_column_udf(self):
        # Create a udf to detect entities in a column
        detect_column_udf = sf.udf(self.detect_column, ArrayType(StructType([StructField('identifier', StringType()), StructField('score', FloatType())])))
        return detect_column_udf

def sdp_image_detection(df, sdp_image_identifiers, threshold):
    """
    sdps_image_detection function aims to perform entity detection in SDPS.
    
    Args:
        df: the df to be detected.
        sdp_image_identifiers: the identifiers to be used for entity detection.
        threshold: the threshold to filter out the results with score less than thresholdFraction.
        
    Returns:
        result_df: the df with column level SDPS detection results."""

    image_column_detector = SDPImageColumnDetector(sdp_image_identifiers)
    detect_image_column_udf = image_column_detector.create_detect_image_column_udf()

    # Perform entity detection in SDPS
    identity_columns = {}
    for column in df.columns:
        identity_columns[column] = column+'_identity_types'
        df = df.withColumn(column+'_identity_types', detect_image_column_udf(column, sf.lit(column)))
    # Summarize the column level detection results
    expr_str = ', '.join([f"'{k}', `{v}`"for k, v in identity_columns.items()])
    expr_str = f"stack({len(identity_columns)}, {expr_str}) as (column_name,identity_types)"
    result_df = df.select(sf.expr(expr_str))\
        .select('column_name', sf.explode('identity_types'))\
        .select('col.*', '*').groupBy('column_name', 'identifier').agg(sf.sum('score').alias('score'))\
        .withColumn('score', sf.col('score'))\
        .where(f'score > {threshold}')\
        .withColumn('identifier', sf.struct('identifier', 'score'))\
        .groupBy('column_name').agg(sf.collect_list('identifier').alias('identifiers'))
    
    return result_df