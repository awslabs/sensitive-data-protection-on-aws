import re
import pyspark.sql.functions as sf
import sdpsner
from pyspark.sql.types import ArrayType, StringType, FloatType, DoubleType, StructType, StructField

class SDPDocumentColumnDetector:
    """
    ColumnDetector is used to detect entities in a column.
    """
    def __init__(self, sdp_identifiers, job_include_keywords, job_exclude_keywords):
        self.sdp_identifiers = sdp_identifiers
        self.job_include_keywords = job_include_keywords
        self.job_exclude_keywords = job_exclude_keywords
    
    def search_context(self, rule, col_val, identifier_include_keywords, identifier_exclude_keywords, identifier_max_distance):
        """
        search_context serves as a function to search the context of a match.
        
        Args:
            rule: The regex rule to be used for searching context.
            col_val: The value in a cell to be detected.
            identifier_include_keywords: The include keywords of an identifier.
            identifier_exclude_keywords: The exclude keywords of an identifier.
            identifier_max_distance: The max distance of an identifier.

        Returns:
            exact_matches: The matches that meet the include and exclude keywords requirements.
            
        """

        include_matches = []

        if not rule:
            for keyword in identifier_include_keywords:
                matches = re.finditer(keyword, col_val)
                for match_obj in matches:
                    # append string in exact_matches:
                    include_matches.append(match_obj.group())
            return include_matches
        else:
            matches = re.finditer(rule, col_val)
            for match_obj in matches:
                # get index of each match
                start_index = match_obj.start()
                end_index = match_obj.end()
                # get the context of each match
            
                # check if the context contains the include keywords
                for keyword in identifier_include_keywords:
                    edited_max_distance = identifier_max_distance + len(keyword)
                    context = col_val[max(0, start_index - edited_max_distance):min(len(col_val), end_index + edited_max_distance)]

                    if keyword in context:
                        include_matches.append(context)
                        break
        
        exact_matches = []
        # check if the context contains the exclude keywords
        for include_match in include_matches:
            is_exclude = False
            for keyword in identifier_exclude_keywords:
                if keyword in include_match:
                    is_exclude = True
                    break
            if not is_exclude:
                exact_matches.append(include_match)
        
        return exact_matches
    
    def job_keyword_search(self, col_val):
        """
        job_keyword_search serves as a function to search the context of a match.
        
        Args:
            col_val: The value in a cell to be detected.

        Returns:
            result: The matches that meet the include and exclude keywords requirements.
            
        """

        search_result = None

        for keyword in self.job_include_keywords:
            if keyword in col_val:
                return ['IncludeJobKeyword', keyword]
        
        for keyword in self.job_exclude_keywords:
            if keyword in col_val:
                return ['ExcludeJobKeyword', keyword]
        return search_result
    
    def detect_column(self, col_val, column_name):
        """
        detect_column serves as a function to construct a udf 
        to detect entities inside a dataframe. 

        sdpsner predict() sample output: 
        sdpsner.predict('Mike James') = {'Mike James': [{'Identifier': 'ENGLISH-NAME', 'Score': 0.99523854}]}

        Args:
            col_val: The value in a cell to be detected
            column_name: The name of a column
        
        Returns:
            result = [{'identifier': 'CHINESE-NAME', 'score': 0.5},
                {'identifier': 'ENGLISH-NAME', 'score': 0.4}]
        """

        result = []

        job_keyword_search_result = self.job_keyword_search(str(col_val))
        if job_keyword_search_result:
            result.append({'identifier': job_keyword_search_result[0], 'score': 1.0})
        else:
            ml_result = sdpsner.predictUnstructured(str(col_val)).get(str(col_val), [])
            ml_label_mapping = {'PER': 'CHINA_CHINESE_NAME',
                                'LOC': 'CHINA_ADDRESS'}

            # iterate through all identifiers(including Regex and ML) to detect entities in col_val
            for identifier in self.sdp_identifiers:
                # Get identifier and skip Glue identifier when identifier type is 2

                identifier_include_keywords = identifier.get('header_keywords', [])
                identifier_include_keywords = list(filter(None, identifier_include_keywords)) if identifier_include_keywords else []
                identifier_exclude_keywords = identifier.get('exclude_keywords', [])
                identifier_exclude_keywords = list(filter(None, identifier_exclude_keywords)) if identifier_exclude_keywords else []
                identifier_max_distance = identifier.get('max_distance', 0)
                identifier_max_distance = int(identifier_max_distance) if identifier_max_distance else 0
                
                score = 0

                # Regex matching when identifier classification is 1
                if identifier['classification'] == 1:
                    rule = identifier.get('rule', '')
                    exact_matches = self.search_context(rule, col_val, identifier_include_keywords, identifier_exclude_keywords, identifier_max_distance)
                    score = float(len(exact_matches))
                # ML matching when identifier classification is 0
                elif identifier['classification'] == 0:
                    for r in ml_result:
                        if r['Identifier'] in ml_label_mapping.keys():
                            if ml_label_mapping[r['Identifier']] == identifier['name']:
                                score = score + 1
                result.append({'identifier': identifier['name'], 'score': float(score)})

        return result
    
    def create_detect_column_udf(self):
        # Create a udf to detect entities in a column
        detect_column_udf = sf.udf(self.detect_column, 
            ArrayType(
                StructType([StructField('identifier', StringType()), 
                            StructField('score', FloatType())
                            ])
                )
            )
        return detect_column_udf

def filter_by_threshold(df, sdp_identifiers):
    """
    This function aims to filter out the identifiers that occur less than the threshold.

    Args:
        df: the df to be filtered.
        sdp_identifiers: the identifiers to be used for entity detection in SDPS.

    Returns:
        df: the df with column level detection results.
    """
    # Get identifier column in df and convert to list
    identifier_column = df.select('identifier').collect()
    distinct_identifier_column = []
    for row in list(set(identifier_column)):
        distinct_identifier_column.append(row['identifier'])

    min_occurrence_dict = {}
    for sdp_identifier in sdp_identifiers:
        if sdp_identifier['name'] in distinct_identifier_column:
            identifier_min_occurence = sdp_identifier.get('min_occurrence', 1)
            min_occurrence_dict[sdp_identifier['name']] = int(identifier_min_occurence) if identifier_min_occurence else 1

    # Filter out the identifiers that occur less than the threshold
    for key, value in min_occurrence_dict.items():
        df = df.filter(~ ((sf.col('identifier') == key) & (sf.col('score') < value)))
    return df

def sdp_entity_detection(df, sdp_identifiers, job_include_keywords, job_exclude_keywords):
    """
    sdps_entity_detection function aims to perform entity detection in SDPS.
    
    Args:
        df: the df to be detected.
        threshold: the threshold to filter out the results with score less than thresholdFraction.
        detect_column_udf: the udf to be used for entity detection.
        
    Returns:
        result_df: the df with column level SDPS detection results."""

    if len(sdp_identifiers) == 0:
        return None

    column_detector = SDPDocumentColumnDetector(sdp_identifiers, job_include_keywords, job_exclude_keywords)
    detect_column_udf = column_detector.create_detect_column_udf()

    # Perform entity detection in SDPS
    identity_columns = {}
    for column in df.columns:
        identity_columns[column] = column+'_identity_types'
        df = df.withColumn(column+'_identity_types', detect_column_udf(column, sf.lit(column)))
    df.show(truncate=False)
    # Summarize the column level detection results
    expr_str = ', '.join([f"'{k}', `{v}`"for k, v in identity_columns.items()])
    expr_str = f"stack({len(identity_columns)}, {expr_str}) as (column_name,identity_types)"
    result_df = df.select(sf.expr(expr_str))\
        .select('column_name', sf.explode('identity_types'))\
        .select('col.*', '*').groupBy('column_name', 'identifier').agg(sf.sum('score').alias('score'))
    result_df = filter_by_threshold(result_df, sdp_identifiers)
    result_df = result_df.withColumn('identifier', sf.struct('identifier', 'score'))\
        .groupBy('column_name').agg(sf.collect_list('identifier').alias('identifiers'))
    result_df.show(truncate=False)
    return result_df