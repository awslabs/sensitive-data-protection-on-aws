from pyspark.sql import DataFrame
import pyspark.sql.functions as sf
from awsglueml.transforms import EntityDetector
from awsglue.dynamicframe import DynamicFrame

def post_process_glue_result(glue_result_df):
    """
    post_process_glue_result function aims to filter false positive results in Glue.
    More rules will be added in this function in the future.
    """
    # processed_glue_result_df = glue_result_df.filter((sf.col('entityType') != 'PERSON_NAME') | (sf.col('column_name').rlike("name|姓名|^col")))
    processed_glue_result_df = glue_result_df
    return processed_glue_result_df

def classifyColumnsAfterRowLevel(nonEmptySampledDf: DataFrame, glue_identifiers):
    """
    classifyColumnsAfterRowLevel function aims to summarize column level detection results
    after performing row level detection in Glue.
    
    Args:
        nonEmptySampledDf: the df after performing row level detection in Glue.
    
    Returns:
        glue_entities_df: the df with column level detection results.
    """

    rows = nonEmptySampledDf.count()

    glue_entities_df = nonEmptySampledDf.select(sf.explode(sf.col("DetectedEntities")).alias("column_name", "entities"))\
        .selectExpr("column_name", "explode(entities) as entity")\
        .selectExpr("column_name", "entity.entityType")
    glue_entities_df = glue_entities_df.withColumn("score", sf.lit(1.0))\
        .groupBy('column_name', 'entityType').agg(sf.sum('score').alias('score'))\
        .withColumnRenamed("entityType", "identifier")
    glue_entities_df = filter_by_threshold(glue_entities_df, glue_identifiers)
    glue_entities_df = glue_entities_df.withColumn('identifiers', sf.struct('identifier', 'score'))\
        .groupBy('column_name').agg(sf.collect_list('identifiers').alias('identifiers'))\

    return glue_entities_df

def filter_by_threshold(df, glue_identifiers):
    """
    This function aims to filter out the identifiers that occur less than the threshold.

    Args:
        df: the df to be filtered.
        glue_identifiers: the identifiers to be used for entity detection in SDPS.

    Returns:
        df: the df with column level detection results.
    """
    # Get identifier column in df and convert to list
    identifier_column = df.select('identifier').collect()
    distinct_identifier_column = []
    for row in list(set(identifier_column)):
        distinct_identifier_column.append(row['identifier'])

    min_occurrence_dict = {}
    for glue_identifier in glue_identifiers:
        if glue_identifier['name'] in distinct_identifier_column:
            identifier_min_occurence = glue_identifier.get('min_occurrence', 1)
            min_occurrence_dict[glue_identifier['name']] = identifier_min_occurence if identifier_min_occurence else 1

    # Filter out the identifiers that occur less than the threshold
    for key, value in min_occurrence_dict.items():
        df = df.filter(~ ((sf.col('identifier') == key) & (sf.col('score') < value)))
    return df

def glue_entity_detection(df, glueContext, glue_identifiers):
    """
    glue_entity_detection function aims to perform entity detection in Glue.
    
    Args:
        df: the df to be detected.
        glueContext: the glueContext to perform entity detection.
        glue_identifiers: the identifiers to be used for entity detection in Glue.
        threshold: the threshold to filter out the results with score less than thresholdFraction.
    
    Returns:
        glue_detector_result: the df with column level detection results.
        """

    if len(glue_identifiers) == 0:
        return None

    glue_identifiers_names = []
    for identifier in glue_identifiers:
        glue_identifiers_names.append(identifier['name'])

    # Perform entity detection in Glue
    dynamic_df = DynamicFrame.fromDF(df, glueContext, "dynamic_df")

    entity_detector = EntityDetector()
    DetectSensitiveData_node1 = entity_detector.detect(
        dynamic_df,
        glue_identifiers_names,
        "DetectedEntities",
    )

    glue_detector_result = classifyColumnsAfterRowLevel(DetectSensitiveData_node1.toDF(), glue_identifiers)

    return glue_detector_result