import json
import math
import re
from urllib.parse import urlparse

import pyspark.sql.functions as sf
from pyspark.sql.types import ArrayType, StringType


def mask_data(col_val):
    """
    This mask_data is used to created a udf for masking data.
    The input is a list of strings. The column to be detected is a column of lists.
    If a string is longer than 100, we display the first 80 characters,
    and display the following characters using * (at most 20 *)
    """

    def mask_string(s):
        length = len(s)
        first_80_percent = math.floor(length * 0.8)
        display_length = min(first_80_percent, 80)
        masked_length = min(20, length - display_length)
        return s[:display_length] + "*" * (masked_length)

    return [mask_string(s) for s in col_val]


def calculate_luhn_checksum(input_string):
    """
    Compute the Luhn checksum for the provided string of digits. Note this
    assumes the check digit is in place.
    """
    digits = list(map(int, input_string))
    odd_sum = sum(digits[-1::-2])
    even_sum = sum([sum(divmod(2 * d, 10)) for d in digits[-2::-2]])
    return (odd_sum + even_sum) % 10


def verify_luhn(input_string):
    """
    Check if the provided string of digits satisfies the Luhn checksum.
    """
    return calculate_luhn_checksum(input_string) == 0


def create_mask_data_udf():
    mask_data_udf = sf.udf(mask_data, ArrayType(StringType()))
    return mask_data_udf


def get_table_info(table, args):
    """
    Retrieves basic information about the table.

    Args:
        table (dict): The table from the crawler to be detected.
        args (dict): Additional arguments.

    Returns:
        dict: A dictionary containing the following information:
            - s3_location (str): The S3 location of the crawler table.
            - s3_bucket (str): The S3 bucket of the crawler table.
            - rds_instance_id (str): The RDS instance ID of the crawler table.
    """
    s3_location = "NA"
    s3_bucket = "NA"
    rds_instance_id = "NA"
    s3_original_file_type = "NA"

    database_type = args.get("DatabaseType")

    if database_type == "s3_unstructured":
        original_file_path = table["Parameters"]["originalFilePath"]
        s3_bucket = table["Parameters"]["originalFileBucketName"]
        s3_location = f"s3://{s3_bucket}/{original_file_path}/"
        s3_original_file_sample = table["Parameters"]["originalFileSample"]
    elif database_type == "rds":
        rds_instance_id = args.get("DatabaseName")

    return {
        "location": s3_location,
        "s3_location": s3_location,
        "s3_bucket": s3_bucket,
        "s3_original_file_sample": s3_original_file_sample,
        "rds_instance_id": rds_instance_id,
    }


def remove_symbols(input_string):
    # Define the pattern to match symbols
    symbol_pattern = r"\W"

    # Remove symbols using regular expression substitution
    output_string = re.sub(symbol_pattern, "_", input_string)

    return output_string


# Define a function to create a new column
def revert_filename(column_name, original_file_sample):
    """
    revert_filename reverts the column name to the original file name.

    Args:
        column_name (str): The column name to be reverted.
        original_file_sample (str): The original file sample.

    Returns:
        str: The reverted column name.
    """

    # If the column name contains dot, it is already the original file name.
    if "." in column_name:
        return column_name

    # Otherwise, we need to revert the column name to the original file name.
    original_sample_files = json.loads(original_file_sample)
    for sample_file in original_sample_files:
        sample_file_name_no_dot = remove_symbols(sample_file)
        if column_name == sample_file_name_no_dot.lower():
            return sample_file
    return ".".join(column_name.rsplit("_", 1))


def create_revert_filename_udf():
    """
    Create a udf for revert_filename.
    """
    revert_filename_udf = sf.udf(revert_filename, StringType())
    return revert_filename_udf


def add_metadata(data_frame, table, args):
    """
    add_metadata adds metadata columns to the df.
    """
    # Add metadata columns to the df
    basic_table_info = get_table_info(table, args)
    revert_filename_udf = create_revert_filename_udf()
    original_file_sample = basic_table_info["s3_original_file_sample"]

    data_frame = data_frame.withColumn("account_id", sf.lit(args["AccountId"]))
    data_frame = data_frame.withColumn("job_id", sf.lit(args["JobId"]))
    data_frame = data_frame.withColumn("run_id", sf.lit(args["RunId"]))
    data_frame = data_frame.withColumn("run_database_id", sf.lit(args["RunDatabaseId"]))
    data_frame = data_frame.withColumn("database_name", sf.lit(args["DatabaseName"]))
    data_frame = data_frame.withColumn("database_type", sf.lit("unstructured"))
    data_frame = data_frame.withColumn("table_name", sf.lit(table["Name"]))
    data_frame = data_frame.withColumn("region", sf.lit(args["Region"]))
    data_frame = data_frame.withColumn(
        "update_time", sf.from_utc_timestamp(sf.current_timestamp(), "UTC")
    )
    data_frame = data_frame.withColumn(
        "location",
        sf.concat(
            sf.lit(basic_table_info["location"]),
            revert_filename_udf(sf.col("column_name"), sf.lit(original_file_sample)),
        ),
    )
    data_frame = data_frame.withColumn(
        "s3_location",
        sf.concat(
            sf.lit(basic_table_info["s3_location"]),
            revert_filename_udf(sf.col("column_name"), sf.lit(original_file_sample)),
        ),
    )
    data_frame = data_frame.withColumn(
        "s3_bucket", sf.lit(basic_table_info["s3_bucket"])
    )
    data_frame = data_frame.withColumn(
        "rds_instance_id", sf.lit(basic_table_info["rds_instance_id"])
    )
    data_frame = data_frame.withColumn(
        "privacy", sf.expr("case when identifiers is null then 0 else 1 end")
    )
    data_frame = data_frame.withColumn("year", sf.year(sf.col("update_time")))
    data_frame = data_frame.withColumn("month", sf.month(sf.col("update_time")))
    data_frame = data_frame.withColumn("day", sf.dayofmonth(sf.col("update_time")))

    return data_frame
