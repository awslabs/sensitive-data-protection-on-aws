
import pyspark.sql.functions as sf
from pyspark.sql.types import ArrayType, StringType, DoubleType, StructType, StructField, IntegerType

from .process_dataframe import preprocess_df, postprocess_df
from .glue_detection import glue_entity_detection
from .sdp_text_detection import sdp_entity_detection
from .sdp_image_detection import sdp_image_detection

def detect_df(df, glueContext, broadcast_template, table, args):
    """
    detect_table is the main function to perform PII detection in a crawler table.

    Args:
        df: the df to be detected.
        glueContext: the glueContext to perform entity detection.
        broadcast_template: the broadcast template to be used for entity detection.
        args: the args dict containing all the parameters for this SDPS Job.
    
    Returns:
        result_df: the df with column level detection results.
    """

    spark = glueContext.spark_session
    threshold = 0
    glue_identifiers = broadcast_template.value.get('glue_identifiers')
    sdp_identifiers = broadcast_template.value.get('sdp_identifiers')
    sdp_image_identifiers = broadcast_template.value.get('sdp_image_identifiers', [])

    raw_job_include_keywords = args['IncludeKeywords'].split(',') if args['IncludeKeywords'] else []
    job_include_keywords = list(filter(None, raw_job_include_keywords))
    raw_job_exclude_keywords = args['ExcludeKeywords'].split(',') if args['ExcludeKeywords'] else []
    job_exclude_keywords = list(filter(None, raw_job_exclude_keywords))

    table_size = df.count() if df else 0
    table_column_size = len(df.columns) if df else 0

    file_category = table['Parameters']['originalFileCategory']

    default_df_schema = StructType([
            StructField("identifiers", ArrayType(StructType(
                            [StructField("identifier",StringType(),True),
                             StructField("score",DoubleType(),True)]
                             ),True), True),
            StructField("column_name", StringType(), True),
            StructField("sample_data", ArrayType(StringType()), True),
            StructField("table_size", IntegerType(), True)
        ])

    if table_size == 0:
        data_frame = spark.createDataFrame([(None, "", ["Table size is 0"], 0)], default_df_schema)
    elif table_column_size == 0:
        data_frame = spark.createDataFrame([(None, "", ["Table column size is 0"], 0)], default_df_schema)
    elif file_category == 'include_files':
        dataframe_content = [
            ([("IncludeFile", 1.0)], column, ["This file is marked as Contains-PII."], 1)
            for column in df.columns if column != "index"
        ]
        data_frame = spark.createDataFrame(dataframe_content, default_df_schema)
    elif file_category == 'exclude_files':
        dataframe_content = [
            (None, column, ["This file is marked as Non-PII."], 1)
            for column in df.columns if column != "index"
        ]
        data_frame = spark.createDataFrame(dataframe_content, default_df_schema)
    elif table['Parameters']['originalFileType'] in ['.jpg', '.jpeg', '.png', '.bmp', '.gif']:
        threshold = 0
        df = preprocess_df(df)
        sample_df = df.limit(10)
        result_df = sdp_image_detection(df, sdp_image_identifiers, threshold)
        data_frame = postprocess_df(result_df, sample_df, table_size)
    else:
        df = preprocess_df(df)
        sample_df = df.limit(10)

        # Perform entity detection in Glue and SDPS
        glue_result_df = glue_entity_detection(df, glueContext, glue_identifiers)
        sdp_result_df = sdp_entity_detection(df, sdp_identifiers, job_include_keywords, job_exclude_keywords)

        # Combine the results from Glue and SDPS
        if glue_result_df == None:
            result_df = sdp_result_df
        elif sdp_result_df == None:
            result_df = glue_result_df
        else:
            union_result_df = glue_result_df.union(sdp_result_df)
            result_df = union_result_df.groupBy('column_name').agg(sf.collect_list('identifiers').alias('identifiers'))
            result_df = result_df.select('column_name', sf.flatten('identifiers').alias('identifiers'))
        data_frame = postprocess_df(result_df, sample_df, table_size)

    return data_frame