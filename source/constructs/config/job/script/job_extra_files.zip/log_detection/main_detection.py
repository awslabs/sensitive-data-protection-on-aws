import json
import logging
import os
from pathlib import Path
from tempfile import NamedTemporaryFile

import boto3
import pyspark.sql.functions as sf
from log_detection.sdp_log_detection import sdp_log_detection
from pyspark.sql.types import (
    ArrayType,
    DoubleType,
    FloatType,
    IntegerType,
    StringType,
    StructField,
    StructType,
)

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)


def download_from_s3(s3_client, s3_bucket, s3_key):
    print(f"Downloading from s3://{s3_bucket}/{s3_key}")
    suffixes = Path(s3_key).suffixes
    suffix = suffixes[-1]

    # if the suffix is .gz, the suffix is .json.gz or .log.gz
    if suffixes[-1] == ".gz":
        if len(suffixes) > 1 and suffixes[-2] in [".json", ".log"]:
            suffix = suffixes[-2] + suffixes[-1]

    with NamedTemporaryFile(delete=False, suffix=suffix) as temp_file:
        s3_client.download_fileobj(s3_bucket, s3_key, temp_file)
        return temp_file.name


def download_and_detect(object_key, log_type, source_data_bucket_name):
    result = []
    try:
        s3_client = boto3.client("s3", use_ssl=False)
        source_file_path = download_from_s3(
            s3_client, source_data_bucket_name, object_key
        )
        result = sdp_log_detection(source_file_path, log_type)
        os.unlink(source_file_path)
    except Exception as e:
        logger.error(f"Error in download_and_detect: {e}")

    return result


def detect_df(df, glue_context, broadcast_template, args):
    """
    detect_table is the main function to perform PII detection in a crawler table.

    Args:
        df: the df to be detected.
        glue_context: the glueContext to perform entity detection.
        broadcast_template: the broadcast template to be used for entity detection.
        args: the args dict containing all the parameters for this SDPS Job.

    Returns:
        result_df: the df with column level detection results.
    """

    spark_session = glue_context.spark_session
    default_df_schema = StructType(
        [
            StructField(
                "identifiers",
                ArrayType(
                    StructType(
                        [
                            StructField("identifier", StringType(), True),
                            StructField("score", DoubleType(), True),
                        ]
                    ),
                    True,
                ),
                True,
            ),
            StructField("column_name", StringType(), True),
            StructField("table_size", IntegerType(), True),
        ]
    )

    download_and_detect_udf = sf.udf(
        download_and_detect,
        ArrayType(
            StructType(
                [
                    StructField("identifier", StringType(), True),
                    StructField("score", DoubleType(), True),
                ]
            ),
            True,
        ),
    )
    result_df = df.withColumn(
        "identifiers",
        download_and_detect_udf(
            df.object_key, df.log_type, sf.lit(args["DatabaseName"])
        ),
    )

    result_df = result_df.filter(sf.col("identifiers").isNotNull())

    # If result_df is empty, return a default df with default schema
    if result_df.rdd.isEmpty():
        dataframe_content = [(None, "all-files", 1)]
        result_df = spark_session.createDataFrame(dataframe_content, default_df_schema)

    return result_df
