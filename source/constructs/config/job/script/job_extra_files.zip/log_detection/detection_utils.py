import json
import math
import re
from urllib.parse import urlparse

import pyspark.sql.functions as sf
from pyspark.sql.types import ArrayType, StringType


def add_metadata(data_frame, args):
    """
    add_metadata adds metadata columns to the df.
    """
    # Add metadata columns to the df
    # Filter dataframe when identifiers is not null

    # rename object_key to column_name
    data_frame = data_frame.withColumnRenamed("object_key", "column_name")

    # drop column object_size
    data_frame = data_frame.drop("object_size")
    data_frame = data_frame.drop("log_type")

    data_frame = data_frame.withColumn("job_id", sf.lit(args["JobId"]))
    data_frame = data_frame.withColumn("run_id", sf.lit(args["RunId"]))
    data_frame = data_frame.withColumn("run_database_id", sf.lit(args["RunDatabaseId"]))
    data_frame = data_frame.withColumn("account_id", sf.lit(args["AccountId"]))
    data_frame = data_frame.withColumn("region", sf.lit(args["Region"]))
    data_frame = data_frame.withColumn("database_type", sf.lit("log"))
    data_frame = data_frame.withColumn("database_name", sf.lit(args["DatabaseName"]))
    data_frame = data_frame.withColumn("table_name", sf.lit("table_name"))
    data_frame = data_frame.withColumn(
        "sample_data", sf.lit(None).cast(ArrayType(StringType()))
    )
    data_frame = data_frame.withColumn("table_size", sf.lit(1))
    data_frame = data_frame.withColumn("s3_location", sf.lit("s3_location"))
    data_frame = data_frame.withColumn("s3_bucket", sf.lit(args["DatabaseName"]))
    data_frame = data_frame.withColumn("rds_instance_id", sf.lit("NA"))
    data_frame = data_frame.withColumn(
        "update_time", sf.from_utc_timestamp(sf.current_timestamp(), "UTC")
    )
    data_frame = data_frame.withColumn(
        "privacy", sf.expr("case when identifiers is null then 0 else 1 end")
    )
    data_frame = data_frame.withColumn("year", sf.year(sf.col("update_time")))
    data_frame = data_frame.withColumn("month", sf.month(sf.col("update_time")))
    data_frame = data_frame.withColumn("day", sf.dayofmonth(sf.col("update_time")))

    return data_frame


def format_error_record_data(error_message, args):
    """
    error_record_dataframe creates an error record dataframe.
    """
    data = {
        "account_id": args["AccountId"],
        "region": args["Region"],
        "job_id": args["JobId"],
        "run_id": args["RunId"],
        "run_database_id": args["RunDatabaseId"],
        "database_name": args["DatabaseName"],
        "database_type": args["DatabaseType"],
        "table_name": "table_name",
        "s3_location": "s3_location",
        "s3_bucket": args["DatabaseName"],
        "rds_instance_id": "NA",
        "error_message": str(error_message),
    }
    return [data]
