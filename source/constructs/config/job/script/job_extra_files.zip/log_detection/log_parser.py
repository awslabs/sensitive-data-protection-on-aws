import json
import logging
import re
from abc import ABC, abstractmethod
from typing import Dict, Iterable

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)
log_format = "%(asctime)s %(levelname)s %(name)s: %(message)s"


class LogType(ABC):
    """An abstract class represents one type of Logs.

    Each AWS service has its own log format.
    Create a class for each service with an implementation of `parse(line)` to parse its service logs
    """

    _fields = []  # list of fields
    _format = "text"  # log file format, such as json, text, etc.

    @abstractmethod
    def parse(self, line: str):
        """Parse the original raw log record, and return processed json record(s).

        This should be implemented in each service class.
        """
        pass

    @property
    def fields(self):
        return self._fields

    @property
    def format(self):
        return self._format


class WAFWithS3(LogType):
    """An implementation of LogType for WAF Logs"""

    _format = "json"

    def parse(self, lines: Iterable[str]):
        for line in lines:
            try:
                json_record = json.loads(line)
            except Exception:
                logger.info(f"this log is not imported: {line}")
                continue
            yield json_record


class CloudTrail(LogType):
    """An implementation of LogType for CloudTrail Logs"""

    _format = "json"

    def _convert_event(self, cloudtrail_event: dict):
        """Unify all cloudtrail event format for different resources.

        There are different cloudtrail event format in different resources.
        Below logic is trying to unify the format
        In order to load as much as possible
        Otherwise, different format may be rejected with mapper_parsing_exception
        """

        # convert requestParameters.parameters from text to dict
        if "requestParameters" in cloudtrail_event and isinstance(
            cloudtrail_event["requestParameters"], dict
        ):
            cloudtrail_event["requestParameters"] = json.dumps(
                cloudtrail_event["requestParameters"]
            )
        # convert requestParameters.parameters from text to dict
        if "responseElements" in cloudtrail_event and isinstance(
            cloudtrail_event["responseElements"], dict
        ):
            cloudtrail_event["responseElements"] = json.dumps(
                cloudtrail_event["responseElements"]
            )
        return cloudtrail_event

    @abstractmethod
    def parse(self, line: str):
        pass


class CloudTrailWithS3(CloudTrail):
    """An implementation of LogType for CloudTrail Logs"""

    _format = "json"

    def parse(self, lines: Iterable[str]):
        for line in lines:
            try:
                json_records = json.loads(line)["Records"]
            except Exception:
                logger.info(f"this log is not imported: {line}")
                continue
            for cloudtrail_event in json_records:
                yield self._convert_event(cloudtrail_event)


class CloutTrailDigestWithS3(CloudTrail):
    """An implementation of LogType for CloudTrail Digest Logs"""

    _format = "json"

    def parse(self, lines: Iterable[str]):
        for line in lines:
            try:
                json_record = json.loads(line)
            except Exception:
                logger.info(f"this log is not imported: {line}")
                continue
            yield json_record
