import gzip
import json
import logging
import re

from log_detection.log_parser import CloudTrailWithS3, CloutTrailDigestWithS3, WAFWithS3

logging.basicConfig(level=logging.INFO)


class SdpLogPiiDetector:
    def __init__(self):
        self.bank_account_regex = r"\b(?:(?:62\d{14,17})|(?:4(?:\d{15}|\d{12}|\d{18}))|(?:5[1-5]\d{14})|(?:35[2-8]\d{13,16})|(?:37\d{13})|(?:60\d{14,17})|(?:9\d{15,18})|(?:6[3-5]\d{14})|(?:66\d{14,15})|(?:68\d{16,17})|(?:69\d{16})|(?:8[478]\d{14})|(?:566666\d{12})|(?:5[4-5]\d{16})|(?:50\d{14})|(?:405512\d{11})|(?:36088\d{8})|(?:103\d{16}))\b"
        self.bank_account_keywords = [
            "account",
            "bank",
            "debit",
            "账号",
            "账户",
            "卡号",
            "银行卡",
            "储蓄卡",
            "借记卡",
            "zhanghao",
            "zhanghu",
            "kahao",
            "yinhangka",
            "chuxuka",
            "jiejika",
        ]

    def calculate_luhn_checksum(self, input_string):
        """
        Compute the Luhn checksum for the provided string of digits. Note this
        assumes the check digit is in place.
        """
        digits = list(map(int, input_string))
        odd_sum = sum(digits[-1::-2])
        even_sum = sum([sum(divmod(2 * d, 10)) for d in digits[-2::-2]])
        return (odd_sum + even_sum) % 10

    def verify_luhn(self, input_string):
        """
        Check if the provided string of digits satisfies the Luhn checksum.
        """
        return self.calculate_luhn_checksum(input_string) == 0

    def verify_bank_account_keywords(self, input_string):
        """
        Check if the provided string contains bank account related keywords
        """
        return any(
            keyword in input_string.lower() for keyword in self.bank_account_keywords
        )

    def process_string(self, data):
        try:
            # Attempt to parse the string as JSON
            parsed_data = json.loads(data)
            yield from self.check_for_bank_accounts(parsed_data)
        except json.JSONDecodeError:
            # If it's not JSON, check for bank account numbers directly
            yield from self.find_valid_bank_accounts(data)

    def find_valid_bank_accounts(self, data):
        potential_numbers = re.findall(self.bank_account_regex, data)
        for potential_number in potential_numbers:
            if self.verify_luhn(potential_number) and self.verify_bank_account_keywords(
                data
            ):
                # print(data)  # For debugging, consider removing or logging differently
                # print(
                #     type(data)
                # )  # For debugging, consider removing or logging differently
                yield potential_number

    def check_for_bank_accounts(self, data):
        if isinstance(data, dict):
            for key, value in data.items():
                yield from self.check_for_bank_accounts(key)
                yield from self.check_for_bank_accounts(value)
        elif isinstance(data, list):
            for item in data:
                yield from self.check_for_bank_accounts(item)
        elif isinstance(data, str):
            yield from self.process_string(data)

    def parse_detect_bank_account_number(self, json_string):
        valid_accounts = list(self.check_for_bank_accounts(json_string))
        return len(valid_accounts)

    def detect_bank_account_number(self, json_string):
        """
        Updated regex to capture potential bank account numbers for Luhn check
        """
        num_matches = 0
        potential_numbers = re.findall(self.bank_account_regex, json_string)
        for number in potential_numbers:
            if self.verify_luhn(number):
                # Use parse_detect_bank_account_number to eliminate false positives
                num_matches = self.parse_detect_bank_account_number(json_string)
                break
        return num_matches

    def get_nested_value(self, nested_dict, key_path):
        """
        Recursively get a nested value from a dictionary given a path of keys
        """
        current_value = nested_dict
        for key in key_path:
            if isinstance(current_value, dict):
                current_value = current_value.get(key, {})
            else:
                return {}
        return current_value

    def detect_pii_in_cloudtrail_digest_log(self, json_records):
        """
        Detect PII in the CloudTrail digest log

        Ref: https://docs.aws.amazon.com/awscloudtrail/latest/userguide/cloudtrail-log-file-validation-digest-file-structure.html
        """
        pii_count = 0
        for json_record in json_records:
            digest_s3_object = json_record["digestS3Object"]
            # detect PII in the digestS3Object
            if self.detect_bank_account_number(digest_s3_object):
                pii_count += 1

            for logfile in json_record.get("logFiles", []):
                if self.detect_bank_account_number(logfile["s3Object"]):
                    pii_count += 1

        return pii_count

    def detect_pii_in_cloudtrail_log(self, json_records):
        """
        Detect PII in the CloudTrail log

        Ref: https://docs.aws.amazon.com/awscloudtrail/latest/userguide/cloudtrail-log-file-examples.html
        """
        pii_count = 0
        # Define the keys of interest for PII detection
        keys_of_interest = [
            "userIdentity.sessionContext",
            "requestParameters",
            "responseElements",
            "tlsDetails",
            "insightDetails",
        ]

        for json_record in json_records:
            for key in keys_of_interest:
                # Navigate through nested dictionaries using the key path
                value = self.get_nested_value(json_record, key.split("."))
                value_str = json.dumps(value)
                if self.detect_bank_account_number(value_str):
                    pii_count += 1

        return pii_count

    def detect_pii_in_waf_log(self, json_records):
        """
        Detect PII in the WAF log

        Ref: https://docs.aws.amazon.com/waf/latest/developerguide/logging-examples.html
        """
        pii_count = 0
        # Define the keys of interest for PII detection
        keys_of_interest = [
            "httpRequest.headers",
            "httpRequest.uri",
            "httpRequest.args",
            "nonTerminatingMatchingRules",
            "terminatingRuleMatchDetails",
        ]

        for json_record in json_records:
            for key in keys_of_interest:
                # Navigate through nested dictionaries using the key path
                value = self.get_nested_value(json_record, key.split("."))
                value_str = json.dumps(value)
                if self.detect_bank_account_number(value_str):
                    pii_count += 1

        return pii_count


def sdp_log_detection(source_file_path, log_type):
    """
    Detect PII in the log file based on the log type

    Args:
        source_file_path (str): The path to the log file.
        log_type (str): The type of log file.

    Returns:
        int: The number of PII detected in the log file.
    """
    with gzip.open(source_file_path, "rt", encoding="utf-8") as gz_file:
        content = gz_file.readlines()

    pii_detector = SdpLogPiiDetector()
    waf_parser = WAFWithS3()
    cloudtrail_parser = CloudTrailWithS3()
    cloudtrail_digest_parser = CloutTrailDigestWithS3()

    if log_type == "CloudTrail":
        records = cloudtrail_parser.parse(content)
        pii_count = pii_detector.detect_pii_in_cloudtrail_log(records)
    elif log_type == "CloudTrail-Digest":
        records = cloudtrail_digest_parser.parse(content)
        pii_count = pii_detector.detect_pii_in_cloudtrail_digest_log(records)
    elif log_type == "WAF" or log_type == "WAFTest":
        records = waf_parser.parse(content)
        pii_count = pii_detector.detect_pii_in_waf_log(records)
    else:
        print(f"Unsupported log type: {log_type}")
        pii_count = 0

    if pii_count > 0:
        return [
            {"identifier": "CHINA_BANK_CARD_LUHN_CHECKSUM", "score": float(pii_count)}
        ]
    else:
        return None


if __name__ == "__main__":
    import gzip
    from pathlib import Path

    source_file_path = "/home/ubuntu/icyxu/code/solutions/s3-scanner/sample_data/CloudTrail/942636716027_CloudTrail_us-west-2_20230803T0805Z_qkK8uKFdb6azJ78p.json.gz"
    pii_result = sdp_log_detection(source_file_path, "CloudTrail")
    print(pii_result)

    # source_file_path = "/home/ubuntu/icyxu/code/solutions/s3-scanner/sample_data/CloudTrail/942636716027_CloudTrail-Digest_us-west-1_cloudtrail-us-east-2_us-west-2_20240107T110115Z.json.gz"
    # pii_result = sdp_log_detection(source_file_path, "CloudTrail-Digest")
    # print(pii_result)

    # source_file_path = "/home/ubuntu/icyxu/code/solutions/s3-scanner/sample_data/WAF/aws-waf-logs-CL-s3-005e476d-3-2024-02-01-00-12-27-38d26713-36c2-4612-b764-eeac4268eae0.gz"
    # pii_result = sdp_log_detection(source_file_path, "WAF")
    # print(pii_result)
