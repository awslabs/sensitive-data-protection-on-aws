import boto3
from dateutil.parser import parse
import pytz

def get_table_info(glue, database_name, selected_tables):
    """
    get_table_info detects specific crawler tables in one specified database.

    Args:
        database_name (str): The database to store all crawler tables.
        region (str): The AWS region.
        selected_tables (list): The selected tables.

    Returns:
        list: All the crawler tables.
    """

    tables = []
    for table_name in selected_tables:
        try:
            response = glue.get_table(
                DatabaseName=database_name,
                Name=table_name
            )
            if response.get('Table', {}).get('Parameters', {}).get('classification', '') != 'UNKNOWN':
                tables.append(response['Table'])

        except Exception as e:
            # Handle the specific exception or log the error message
            print(f"Error retrieving table '{table_name}': {str(e)}")
    return tables

def get_tables_using_name(glue, database_name, selected_tables, base_time):
    """
    get_tables_using_name detects the crawler table using the table name.

    Args:
        database_name (str): The database to store all crawler tables.
        region (str): The AWS region.
        base_time (str): The base time for filtering updated tables.
        selected_tables (list): The selected tables.

    Returns:
        list: The crawler tables.
    """
    tables = []

    for table_name in selected_tables:
        try:
            response = glue.get_table(
                DatabaseName=database_name,
                Name=table_name
            )
            if response.get('Table', {}).get('UpdateTime') > base_time:
                if response.get('Table', {}).get('Parameters', {}).get('classification', '') != 'UNKNOWN':
                    tables.append(response['Table'])
        except Exception as e:
            # Handle the specific exception or log the error message
            print(f"Error retrieving table '{table_name}': {str(e)}")

    return tables

def get_tables_using_range(glue, database_name, table_range, base_time):
    """
    get_tables_using_range detects all the crawler tables in one specified database.
    Only the tables updated after the base time will be returned.

    Args:
        database_name (str): The database to store all crawler tables.
        region (str): The AWS region.
        base_time (str): The base time for filtering updated tables.
        table_range (dict): The table range.

    Returns:
        list: All the crawler tables.
    """

    tables = []

    next_token = ""
    while True:
        response = glue.get_tables(
            DatabaseName=database_name,
            NextToken=next_token
        )
        for table in response.get('TableList', []):
            if table.get('UpdateTime') > base_time:
                if table.get('Parameters', {}).get('classification', '') != 'UNKNOWN':
                    tables.append(table)
        next_token = response.get('NextToken')
        if not next_token:
            break

    table_begin = int(table_range.get("TableBegin", 0))
    table_end = int(table_range.get("TableEnd", len(tables)))
    tables = tables[table_begin:table_end]

    return tables

def get_tables(glue, args, full_database_name = ''):
    """
    Detects all the crawler tables in a specified database.
    Only the tables updated after the base time will be returned.

    Args:
        region: The AWS region.
        args: Additional arguments. Should contain 'BaseTime', 'TableName', 'TableBegin', and 'TableEnd'.

    Returns:
        tables: Selected crawler tables.
    """
    # Input validation
    if not glue or 'DatabaseName' not in args or 'BaseTime' not in args or 'TableName' not in args or 'TableBegin' not in args or 'TableEnd' not in args:
        raise ValueError("Invalid input parameters.")
    
    database_name = full_database_name if full_database_name else args['GlueDatabaseName']
    print(database_name)

    base_time_str = args.get('BaseTime', '1970-01-01 00:00:00')
    base_time = parse(base_time_str).replace(tzinfo=pytz.timezone('UTC'))

    table_names = list(filter(None, args.get('TableName', '').split(',')))
    table_range = {
        "TableBegin": args.get('TableBegin', '-1'),
        "TableEnd": args.get('TableEnd', '-1')
    }

    if str(table_range["TableBegin"]) == '-1':
        tables = get_tables_using_name(glue, database_name, table_names, base_time)
    else:
        tables = get_tables_using_range(glue, database_name, table_range, base_time)

    return tables
