import boto3
import warnings

def construct_dataframe_from_s3(
        glue_context, 
        database_name: str, 
        table, 
        num_rows: int
    ):
    # spark = glue_context.spark_session
    
    # spark.sql(f"USE `{database_name}`")
    # query = f"SELECT * FROM `{table_name}` LIMIT {num_rows}"
    # df = spark.sql(query)
    df = glue_context.create_data_frame_from_catalog(
        database=database_name,
        table_name=table['Name']
    )
    df = df.limit(num_rows)
    return df

def construct_dataframe_from_rds(
        glue_context,
        database_name: str,
        table,
        num_rows: int
    ):
    """
    Constructs a DataFrame from a RDS MySQL table using AWS Glue.

    Args:
        glue_context (GlueContext): AWS Glue context object.
        region (str): AWS region name.
        database_name (str): Name of the database.
        table_name (str): Name of the table.
        num_rows (int): Number of rows to fetch.

    Returns:
        DataFrame: Constructed DataFrame.

    Raises:
        ValueError: If invalid input parameters are provided.
        Exception: If table information or location cannot be retrieved.
    """
    table_info = table
    
    if not table_info:
        raise Exception("Table information not found.")
    
    table_location = table_info['StorageDescriptor']['Location']
    mysql_table_name = table_location.split('.')[-1]
    
    sample_query = f"SELECT * FROM `{mysql_table_name}` LIMIT {num_rows}"
    print(sample_query)
    
    df = glue_context.create_data_frame_from_catalog(
        database=database_name,
        table_name=table['Name'],
        additional_options={"sampleQuery": sample_query}
    )
    
    return df


def construct_dataframe_from_custom_mysql(
    glue_context,
    database_name: str,
    table,
    num_rows: int
):
    """
    Constructs a DataFrame from a custom MySQL table using AWS Glue.

    Args:
        glue_context (GlueContext): AWS Glue context object.
        region (str): AWS region name.
        database_name (str): Name of the database.
        table_name (str): Name of the table.
        num_rows (int): Number of rows to fetch.

    Returns:
        DataFrame: Constructed DataFrame.

    Raises:
        ValueError: If invalid input parameters are provided.
        Exception: If table information or location cannot be retrieved.
    """
    table_info = table
    print(table_info)
    
    if not table_info:
        raise Exception("Table information not found.")
    
    table_location = table_info['StorageDescriptor']['Location']
    mysql_table_name = table_location.split('.')[-1]
    
    sample_query = f"SELECT * FROM `{mysql_table_name}` LIMIT {num_rows}"
    
    df = glue_context.create_data_frame_from_catalog(
        database=database_name,
        table_name=table['Name'],
        additional_options={"sampleQuery": sample_query}
    )
    
    return df

def construct_dataframe(glueContext, glue, table, args):
    """
    A general function to call different construct_dataframe_from_* functions
    """
    database_type = ''
    database_name = table['DatabaseName']

    if args['DatabaseType'] in ['glue', 'jdbc-aws', 'jdbc-tencent', 'jdbc-aliyun']:
        # Get connection of this table
        connection_name = table.get('Parameters', {}).get('connectionName', '')
        if connection_name:
            response = glue.get_connection(Name=connection_name)
            connection_url = response.get('Connection', {}).get('ConnectionProperties', {}).get('JDBC_CONNECTION_URL', '')
            database_type = connection_url.split(':')[1]
        else:
            database_type = 'default'
    else:
        database_type = args['DatabaseType']

    num_rows = int(args.get('Depth', 1000))*10
    print(f"Database type: {database_type}")

    if database_type in ['s3', 's3_unstructured']:
        return construct_dataframe_from_s3(glueContext, database_name, table, num_rows)
    elif database_type == 'rds':
        return construct_dataframe_from_rds(glueContext, database_name, table, num_rows)
    elif database_type == 'mysql':
        return construct_dataframe_from_custom_mysql(glueContext, database_name, table, num_rows)
    else:
        warnings.warn(f"Unsupported database type: {database_type} in table {table['Name']}")
        try:
            possible_df =  construct_dataframe_from_s3(glueContext, database_name, table, num_rows)
            possible_df.show()
            return possible_df
        except Exception as e:
            print(e)
            return None

